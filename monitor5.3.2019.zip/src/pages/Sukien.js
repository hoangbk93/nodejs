import React, { Component } from 'react';
import {
	Link
} from 'react-router-dom';

class Sukien extends Component {
    
  render() {
  	
    return (
    	<main id="main_SK">
        <div className="banner">
            <img src="images/background-banner-detail.gif" alt="" />
        </div>
        <div className="content_main">
            <div className="bs-container">
                <div className="title_content">
                    <i data-aos="fade-right" data-aos-delay="400" className="fas fa-home"></i>
                    <h4 data-aos="fade-right" data-aos-delay="200">TRANG CHỦ/ CHI TIẾT SK</h4>
                </div>
                <div className="form_content">
                    <div className="title_form">
                        <h4 className="title" data-aos="fade-down" data-aos-delay="400">SỰ KIỆN BẦU CHỨC VỊ CHỦ TỊCH NƯỚC</h4>
                    </div>
                    <div className="content_form">
                        <span className="title" data-aos="fade-down" data-aos-delay="600"><img src="images/icon_title.jpg" alt="" />danh sách ứng cử viên</span>
                        
                        <div className="content">
                            <div className="bs-row">
                            <div className="bs-col tn-100-15 sm-33-15">
                                <div className="item" data-aos="fade-down" data-aos-delay="200">
                                    <div className="img">
                                        <div className="ImagesFrame">
											<div className="ImagesFrameCrop0">
													<img src="images/item-detail.jpg" alt="" />
											</div>
										</div>
                                    </div>
                                    <div className="info">
                                        <span className="nickname">Đồng chí</span>
                                        <p className="name">Nguyễn Hoàng Chung</p>
                                        <div className="info_detail">
                                            <span className="birth">Sinh ngày: 10/7/1972</span>
                                            <span className="degree">Cử nhân Khoa học - môi trường; Thạc sỹ Quản trị kinh doanh</span>
                                        </div>
                                    </div>
                                    <span className="detail">
                                        <Link className="intro_" to="/ungvien">Chi tiết <i className="fas fa-angle-double-right"></i></Link>
                                    </span>
                                </div>
                            </div>
                             <div className="bs-col tn-100-15 sm-33-15">
                                <div className="item" data-aos="fade-down" data-aos-delay="400">
                                    <div className="img">
                                        <div className="ImagesFrame">
											<div className="ImagesFrameCrop0">
													<img src="images/item-detail1.jpg" alt="" />
											</div>
										</div>
                                    </div>
                                    <div className="info">
                                        <span className="nickname">Đồng chí</span>
                                        <p className="name">Nguyễn Hoàng Chung</p>
                                        <div className="info_detail">
                                            <span className="birth">Sinh ngày: 10/7/1972</span>
                                            <span className="degree">Cử nhân Khoa học - môi trường; Thạc sỹ Quản trị kinh doanh</span>
                                        </div>
                                    </div>
                                    <span className="detail">
                                        <Link className="intro_" to="/ungvien">Chi tiết <i className="fas fa-angle-double-right"></i></Link>
                                    </span>
                                </div>
                            </div>
                             <div className="bs-col tn-100-15 sm-33-15">
                                <div className="item" data-aos="fade-down" data-aos-delay="600">
                                    <div className="img">
                                        <div className="ImagesFrame">
											<div className="ImagesFrameCrop0">
													<img src="images/item-detail2.jpg" alt="" />
											</div>
										</div>
                                    </div>
                                    <div className="info">
                                        <span className="nickname">Đồng chí</span>
                                        <p className="name">Nguyễn Hoàng Chung</p>
                                        <div className="info_detail">
                                            <span className="birth">Sinh ngày: 10/7/1972</span>
                                            <span className="degree">Cử nhân Khoa học - môi trường; Thạc sỹ Quản trị kinh doanh</span>
                                        </div>
                                    </div>
                                    <span className="detail">
                                        <Link className="intro_" to="/ungvien">Chi tiết <i className="fas fa-angle-double-right"></i></Link>
                                    </span>
                                </div>
                            </div>
                             <div className="bs-col tn-100-15 sm-33-15">
                                <div className="item" data-aos="fade-down" data-aos-delay="200">
                                    <div className="img">
                                        <div className="ImagesFrame">
											<div className="ImagesFrameCrop0">
													<img src="images/item-detail3.jpg" alt="" />
											</div>
										</div>
                                    </div>
                                    <div className="info">
                                        <span className="nickname">Đồng chí</span>
                                        <p className="name">Nguyễn Hoàng Chung</p>
                                        <div className="info_detail">
                                            <span className="birth">Sinh ngày: 10/7/1972</span>
                                            <span className="degree">Cử nhân Khoa học - môi trường; Thạc sỹ Quản trị kinh doanh</span>
                                        </div>
                                    </div>
                                    <span className="detail">
                                        <Link className="intro_" to="/ungvien">Chi tiết <i className="fas fa-angle-double-right"></i></Link>
                                    </span>
                                </div>
                            </div>
                             <div className="bs-col tn-100-15 sm-33-15">
                                <div className="item" data-aos="fade-down" data-aos-delay="400">
                                    <div className="img">
                                        <div className="ImagesFrame">
											<div className="ImagesFrameCrop0">
													<img src="images/item-detail4.jpg" alt="" />
											</div>
										</div>
                                    </div>
                                    <div className="info">
                                        <span className="nickname">Đồng chí</span>
                                        <p className="name">Nguyễn Hoàng Chung</p>
                                        <div className="info_detail">
                                            <span className="birth">Sinh ngày: 10/7/1972</span>
                                            <span className="degree">Cử nhân Khoa học - môi trường; Thạc sỹ Quản trị kinh doanh</span>
                                        </div>
                                    </div>
                                    <span className="detail">
                                        <Link className="intro_" to="/ungvien">Chi tiết <i className="fas fa-angle-double-right"></i></Link>
                                    </span>
                                </div>
                            </div>
                             <div className="bs-col tn-100-15 sm-33-15">
                                <div className="item" data-aos="fade-down" data-aos-delay="600">
                                    <div className="img">
                                        <div className="ImagesFrame">
											<div className="ImagesFrameCrop0">
													<img src="images/item-detail5.jpg" alt="" />
											</div>
										</div>
                                    </div>
                                    <div className="info">
                                        <span className="nickname">Đồng chí</span>
                                        <p className="name">Nguyễn Hoàng Chung</p>
                                        <div className="info_detail">
                                            <span className="birth">Sinh ngày: 10/7/1972</span>
                                            <span className="degree">Cử nhân Khoa học - môi trường; Thạc sỹ Quản trị kinh doanh</span>
                                        </div>
                                    </div>
                                    <span className="detail">
                                        <Link className="intro_" to="/ungvien">Chi tiết <i className="fas fa-angle-double-right"></i></Link>
                                    </span>
                                </div>
                            </div>
                        </div>
                        </div>
                        
                        <span className="title_" data-aos="fade-down" data-aos-delay="200"><img src="images/icon_title.jpg" alt="" />danh sách người bỏ phiếu</span>
                        <div className="table" data-aos="fade-up" data-aos-delay="200">
                            <table>
						<tbody>
							<tr className="title">
								<th className="first"><span></span>NGƯỜI BỎ PHIẾU</th>
								<th>CHỨC VỤ</th>
								<th>QUÊ QUÁN</th>
							</tr>
							<tr className="content">
								<td>Nguyễn Hoàng Luân</td>
								<td>Nhân viên chuyển phát nhanh</td>
								<td>Xã Xuân Đài, huyện Xuân Trường, tỉnh Nam Định</td>
							</tr>
							<tr className="content">
								<td>Nguyễn Hoàng Luân</td>
								<td>Nhân viên chuyển phát nhanh</td>
								<td>Xã Xuân Đài, huyện Xuân Trường, tỉnh Nam Định</td>
							</tr>
							<tr className="content">
								<td>Nguyễn Hoàng Luân</td>
								<td>Nhân viên chuyển phát nhanh</td>
								<td>Xã Xuân Đài, huyện Xuân Trường, tỉnh Nam Định</td>
							</tr>
							<tr className="content">
								<td>Nguyễn Hoàng Luân</td>
								<td>Nhân viên chuyển phát nhanh</td>
								<td>Xã Xuân Đài, huyện Xuân Trường, tỉnh Nam Định</td>
							</tr>
							<tr className="content">
								<td>Nguyễn Hoàng Luân</td>
								<td>Nhân viên chuyển phát nhanh</td>
								<td>Xã Xuân Đài, huyện Xuân Trường, tỉnh Nam Định</td>
							</tr>
							<tr className="content">
								<td>Nguyễn Hoàng Luân</td>
								<td>Nhân viên chuyển phát nhanh</td>
								<td>Xã Xuân Đài, huyện Xuân Trường, tỉnh Nam Định</td>
							</tr>
							<tr className="content">
								<td>Nguyễn Hoàng Luân</td>
								<td>Nhân viên chuyển phát nhanh</td>
								<td>Xã Xuân Đài, huyện Xuân Trường, tỉnh Nam Định</td>
							</tr>
							<tr className="content">
								<td>Nguyễn Hoàng Luân</td>
								<td>Nhân viên chuyển phát nhanh</td>
								<td>Xã Xuân Đài, huyện Xuân Trường, tỉnh Nam Định</td>
							</tr>
							<tr className="content">
								<td>Nguyễn Hoàng Luân</td>
								<td>Nhân viên chuyển phát nhanh</td>
								<td>Xã Xuân Đài, huyện Xuân Trường, tỉnh Nam Định</td>
							</tr>
							<tr className="content">
								<td>Nguyễn Hoàng Luân</td>
								<td>Nhân viên chuyển phát nhanh</td>
								<td>Xã Xuân Đài, huyện Xuân Trường, tỉnh Nam Định</td>
							</tr>
						</tbody>
					</table>
                        </div>
                        
                        <nav aria-label="Page navigation example" className="Page">
                          <ul className="pagination">
                            <li className="page-item" data-aos="fade-down" data-aos-delay="200"><a className="page-link" href="#page"><i className="fas fa-fast-backward"></i></a></li>
                            <li className="page-item" data-aos="fade-down" data-aos-delay="300"><a className="page-link" href="#page"><i className="fas fa-angle-double-left"></i></a></li>
                            <li className="page-item" data-aos="fade-down" data-aos-delay="400"><a className="page-link" href="#page">1</a></li>
                            <li className="page-item" data-aos="fade-down" data-aos-delay="500"><a className="page-link" href="#page">2</a></li>
                            <li className="page-item" data-aos="fade-down" data-aos-delay="600"><a className="page-link" href="#page">3</a></li>
                            <li className="page-item" data-aos="fade-down" data-aos-delay="700"><a className="page-link" href="#page">4</a></li>
                            <li className="page-item" data-aos="fade-down" data-aos-delay="800"><a className="page-link" href="#page">...</a></li>
                            <li className="page-item" data-aos="fade-down" data-aos-delay="900"><a className="page-link" href="#page">17</a></li>
                            <li className="page-item" data-aos="fade-down" data-aos-delay="1000"><a className="page-link" href="#page"><i className="fas fa-angle-double-right"></i></a></li>
                            <li className="page-item" data-aos="fade-down" data-aos-delay="1100"><a className="page-link" href="#page"><i className="fas fa-fast-forward"></i></a></li>
                          </ul>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
        
    </main>
      
    );
  }
}

export default Sukien;
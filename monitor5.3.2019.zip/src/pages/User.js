import React, { Component } from 'react';

const test ="DANH SÁCH USER";
function senddata(e){
     e.preventDefault();
    console.log('The link was clicked.');
}
function activateLasers(e){
     e.preventDefault();
   
    console.log("abc");
}

class User extends Component {


    constructor(props) {
    super(props);
    this.state = {value: ''};
    this.state1 = {value1: ''};

    this.handleChange = this.handleChange.bind(this);
    this.handleChange1 = this.handleChange1.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
  }

  handleChange(event) {
    this.setState({value: event.target.value});
    
  }
  handleChange1(event1) {
    this.setState({value1: event1.target.value1});
  }

  handleSubmit(event) {
    alert('A name was submitted: ' + this.state.value);
    alert('A name was submitted: ' + this.state1.value1);
    event.preventDefault();
  }
  render() {
    return (
       <div>
        <div className="page-content-wrapper">
            <div className="page-content">
                <div className="dashboard">

                    <div className="portlet box green1 margin-page">
                        <div className="portlet-title">
                            <div className="caption">
                                <img src="images/ic3.gif" alt="" /> <span>{test}</span> </div>
                            <div className="tools">
                                <a href="#click" className="collapse" data-original-title="" title=""> </a>
                                <a href="#portlet-config" data-toggle="modal" className="config" data-original-title=""
                                    title=""> </a>
                                <a href="#click" className="reload" data-original-title="" title=""> </a>
                                <a href="#click" className="remove" data-original-title="" title=""> </a>
                            </div>
                        </div>
                        <div className="portlet-body">
                            <div className="add-title clearfix">
                                <div className="button-left">
                                    <button data-toggle="modal" href="#large"><i className="fas fa-plus-circle"></i>Thêm mới</button>
                                </div>
                                <div className="search">
                                    <input type="text" placeholder="Tìm kiếm..." />
                                    <button className="icon"><i className="fas fa-search"></i></button>
                                </div>
                            </div>
                            <div className="table-scrollable">
                                <table className="table table-bordered table-hover">
                                    <thead>
                                        <tr>
                                            <th>STT</th>
                                            <th>TÊN USER</th>
                                            <th>HỌ TÊN</th>
                                            <th>ĐƠN VỊ</th>
                                            <th>PHÂN QUYỀN</th>
                                            <th>ACTIVE</th>
                                            <th>SỬA</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td>01</td>
                                            <td>BS_Dung</td>
                                            <td>Bùi Thị Thùy Dung</td>
                                            <td>ByteSoft VN</td>
                                            <td>User</td>
                                            <td><a href="#click"><i className="fas fa-user-check"></i></a></td>
                                            <td><a className="btn btn-outline sbold" data-toggle="modal" href="#large"
                                                    ><i className="far fa-edit"></i></a></td>

                                        </tr>
                                        
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div className="modal fade bs-modal-lg modal-user" id="large" role="dialog" aria-hidden="true">
            <div className="modal-dialog modal-lg">
                <div className="modal-content">
                    <div className="modal-header">
                        <button type="button" className="close" data-dismiss="modal" aria-hidden="true"></button>
                        <h4 className="modal-title">Chỉnh sửa / thêm user</h4>
                    </div>
                    <form onSubmit={this.handleSubmit}>
                    <div className="modal-body">

                        
                        <div className="bs-row bs-row-sm15">
                            <div className="bs-col sm-50-15">
                                <div className="item">
                                    <label>Tên user:</label>
                                    <input type="text" className="input-modal nameuser" value={this.state.value} onChange={this.handleChange} />
                                </div>
                            </div>
                            <div className="bs-col sm-50-15">
                                <div className="item">
                                    <label>Họ tên:</label>
                                    <input type="text" className="input-modal" value={this.state1.value} onChange={this.handleChange1} />
                                </div>
                            </div>
                        </div>
                        
                        <div className="bs-row bs-row-sm15">
                            <div className="bs-col sm-50-15">
                                <div className="item">
                                    <label>Đơn vị:</label>
                                    <input type="text" className="input-modal" />
                                </div>
                            </div>
                            <div className="bs-col sm-50-15">
                                <div className="item">
                                    <label>Trạng thái:</label>
                                    <select id="single" className="form-control select2">
                                        <option>Trạng thái 1</option>
                                        <option>Trạng thái 2</option>
                                        <option>Trạng thái 3</option>


                                    </select>
                                </div>
                            </div>
                        </div>

                    </div>
                    <div className="modal-footer">
                        <input type="submit" value="Submit" />
                        <button type="button" className="btn green" onClick={senddata}><i className="far fa-save" ></i>Lưu</button>
                        <button type="button" className="btn dark btn-outline" data-dismiss="modal"><i className="fas fa-times"></i>Đóng</button>
                    </div>
                    </form>
                </div>
               
            </div>
           
        </div>
        
       
      </div>
    );
  }
}

export default User;
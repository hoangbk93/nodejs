import React, { Component } from 'react';
// var htmlElementAttributes = require('react-html-attributes');
// htmlElementAttributes['*'];

class Demotest extends Component {
  render() {
    return (
    	<h2> demotest</h2>
      
    );
  }
}

export default Demotest;
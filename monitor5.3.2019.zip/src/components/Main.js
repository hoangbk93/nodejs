import React, { Component } from 'react';





var data = null;

var xhr = new XMLHttpRequest();
xhr.withCredentials = true;

xhr.addEventListener("readystatechange", function () {
  if (this.readyState === 4) {
    console.log(this.responseText);
  }
});

xhr.open("GET", "https://graph.facebook.com/v3.2/627505111018144?access_token=EAAC4WbDAyX8BAPeg779VAYo7YD11a9GK7c2GYKIVLsbXJFHR2VNZBJS2KVJZCLkgrTpKZBjASRO4Tz7YWrv5CorcqHZBb4fOMUVXPEyMf3aG8obZAd6qWPLXtFK8yqMzOfUV2oJYGsnRoySZAWJk2bpLThySloN2bDPgHgZADMbplZBjZARDiLZCTrhFUcX1cRjteL1cJnInAYlgZDZD&fields=reactions");
xhr.setRequestHeader("cache-control", "no-cache");
xhr.setRequestHeader("Postman-Token", "4d2a973b-591e-4052-bef2-a4b43e04c69d");

xhr.send(data);

// var data = null;

// var xhr = new XMLHttpRequest();
// xhr.withCredentials = true;

// xhr.addEventListener("readystatechange", function () {
//   if (this.readyState === 4) {
//     console.log(this.responseText);
  
//   }
// });

// xhr.open("GET", "https://vote.bytesoft.net:3000/auth/jwt/callback?token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6IjVjNzc1MmJiZjE5ZDUzMjA2ZTRjYjYzZCIsImlhdCI6MTU1MTY5Njc3NywiZXhwIjoxNTUxNjk2ODM3fQ.WUfFR-ijnocqJ3xTe2p7f0GQQirfTm9czVC155InvcM");
// xhr.setRequestHeader("cache-control", "no-cache");
// xhr.setRequestHeader("Postman-Token", "df1cd3a9-f9ce-4eb9-8c9e-503654fc8e21");

// xhr.send(data);

class Main extends Component {
  render() {
    return ( 
        <div className="page-content-wrapper">
          <div className="page-content">
            <div className="dashboard">
              <div className="menu-option">
                <div className="bs-row bs-row-sm15 bs-row-xs10">
                  <div className="bs-col sm-33-15 xs-33-10">
                    <div className="item">
                      <div className="top">
                        <img className="default" src="images/icon1.gif" alt="" />
                        <img
                          className="hover"
                          src="images/icon1-hover.gif"
                          alt=""
                        />
                      </div>
                      <div className="bottom"><p>ỨNG DỤNG ĐANG HOẠT ĐỘNG</p></div>
                    </div>
                  </div>
                  <div className="bs-col sm-33-15 xs-33-10">
                    <div className="item">
                      <div className="top">
                        <img className="default" src="images/icon2.gif" alt="" />
                        <img
                          className="hover"
                          src="images/icon2-hover.gif"
                          alt=""
                        />
                      </div>
                      <div className="bottom"><p>NGƯỜI DÙNG ĐANG HOẠT ĐỘNG</p></div>
                    </div>
                  </div>
                  <div className="bs-col sm-33-15 xs-33-10">
                    <div className="item">
                      <div className="top">
                        <img className="default" src="images/icon3.gif" alt="" />
                        <img
                          className="hover"
                          src="images/icon3-hover.gif"
                          alt=""
                        />
                      </div>
                      <div className="bottom"><p>QUẢN TRỊ VIÊN</p></div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="portlet box green1">
                  <div className="portlet-title">
                      <div className="caption">
                          <img src="images/ic3.gif" alt="" /> <span>BÁO CÁO HÀNG NGÀY </span> </div>
                      <div className="tools">
                          <a href="#click" className="collapse" data-original-title="" title=""> </a>
                          <a href="#portlet-config" data-toggle="modal" className="config" data-original-title="" title=""> </a>
                          <a href="#click" className="reload" data-original-title="" title=""> </a>
                          <a href="#click" className="remove" data-original-title="" title=""> </a>
                      </div>
                  </div>
                  <div className="portlet-body">
                      <div className="table-scrollable">
                          <table className="table table-bordered table-hover">
                              <thead>
                                  <tr>
                                      <th>STT</th>
                                      <th></th>
                                      <th></th>
                                      <th></th>
                                      <th></th>
                                      <th></th>
                                      <th></th>
                                      <th></th>
                                      <th></th>
                                  </tr>
                              </thead>
                              <tbody>
                                  <tr>
                                      <td></td>
                                      <td></td>
                                      <td></td>
                                      <td></td>
                                      <td></td>
                                      <td></td>
                                      <td></td>
                                      <td></td>
                                      <td></td>
                                  </tr>
                                 
                              </tbody>
                          </table>
                      </div>
                  </div>
              </div>
            </div>
          </div>
        </div>
        
      
   );
  }
}

export default Main;

import React, { Component } from 'react';


class Product extends Component {
  render() {
    return (
    	<h3> product</h3>
      
    );
  }
}

export default Product;
